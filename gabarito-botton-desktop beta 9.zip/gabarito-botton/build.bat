@echo off
cd /d "%~dp0"
call npm install
call npm run dist:win
echo.
echo Pronto! O executavel esta na pasta dist.
pause
